package com.example.CarServicePart_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class CarRegisterationPart_1ApplicationTests {

	@Test
	void contextLoads() {
	}
}
